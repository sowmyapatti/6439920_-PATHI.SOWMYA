import java.util.HashMap;
import java.util.Scanner;

public class HashMapExample {
    public static void main(String[] args) {
        HashMap<Integer, String> studentMap = new HashMap<>();
        Scanner sc = new Scanner(System.in);
        System.out.println("Add student entries (ID and Name), type ID as -1 to stop:");
        while (true) {
            System.out.print("Enter student ID: ");
            int id = sc.nextInt();
            if (id == -1) break;
            sc.nextLine(); // consume newline
            System.out.print("Enter student Name: ");
            String name = sc.nextLine();
            studentMap.put(id, name);
        }
        System.out.print("Enter ID to retrieve: ");
        int searchId = sc.nextInt();
        String studentName = studentMap.get(searchId);
        if (studentName != null) {
            System.out.println("Name for ID " + searchId + ": " + studentName);
        } else {
            System.out.println("ID not found.");
        }
        sc.close();
    }
}
