import java.sql.*;

public class Exercise32_JDBCInsertUpdate {
    public static void main(String[] args) throws Exception {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:test.db");
        PreparedStatement ps = conn.prepareStatement("INSERT INTO students(name) VALUES(?)");
        ps.setString(1, "New Student");
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
