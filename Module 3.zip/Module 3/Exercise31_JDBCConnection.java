import java.sql.*;

public class Exercise31_JDBCConnection {
    public static void main(String[] args) throws Exception {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:test.db");
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM students");
        while (rs.next()) {
            System.out.println(rs.getString("name"));
        }
        rs.close(); stmt.close(); conn.close();
    }
}
