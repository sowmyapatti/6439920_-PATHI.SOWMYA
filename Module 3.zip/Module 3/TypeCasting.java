// TypeCasting.java
public class TypeCasting {
    public static void main(String[] args) {
        double doubleValue = 9.99;
        int intValue = (int) doubleValue; // Explicit casting

        int anotherInt = 20;
        double anotherDouble = anotherInt; // Implicit casting

        System.out.println("Double to Int: " + intValue);
        System.out.println("Int to Double: " + anotherDouble);
    }
}
